import subprocess
import sys

p = subprocess.Popen('python server_tcp.py ' + sys.argv[1] + " " + sys.argv[2], shell = True)
q = subprocess.Popen('python main.py ' + sys.argv[1] + " " + sys.argv[2], shell = True)
p.wait()
q.wait()

