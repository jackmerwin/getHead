import titlescreen, sys

if __name__ == "__main__":	
	t = titlescreen.Titlescreen(sys.argv[1], sys.argv[2])
