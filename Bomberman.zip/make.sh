python setup.py py2app --iconfile Bomberman.icns
