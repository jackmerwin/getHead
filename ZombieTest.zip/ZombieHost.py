import subprocess
import sys

p = subprocess.Popen('python xmlserver.py ' + sys.argv[1], shell = True)
q = subprocess.Popen('python ZombieTest.py ' + sys.argv[1], shell = True)
p.wait()
q.wait()
