import xmlrpclib
import socket
import subprocess
import os
import pygame
import random
from pygame.locals import *
from pygame.color import THECOLORS
import math
import sys

serv = xmlrpclib.ServerProxy("http://"+sys.argv[1]+":2221")

def startGame(screenX, screenY, caption, background, cursorVisible):
	pygame.init()
	global screen
	global background_image
	screen = pygame.display.set_mode((screenX, screenY))
	pygame.display.set_caption(caption)
	background_image, background_rect = loadImage(background)
	screen.blit(background_image, (0,0))
	pygame.mouse.set_visible(cursorVisible)

def loadImage(name, colorKey = None):
	completeName = os.path.join('ZombieResources',name) # Get a full name
	image = pygame.image.load(completeName) # load the image
	image = image.convert() # Convert the image for speed
	if colorKey != None: # colorkey (transparency) calculation
		if colorKey == -1:
			colorKey = image.get_at((0,0))
		image.set_colorkey(colorKey)
	return image, image.get_rect() 

class laserObject(pygame.sprite.Sprite):
	def __init__(self, name, image, x, y, maxX, maxY,xMove, yMove, colorKey = -1, minX = 0, minY = 0):
		pygame.sprite.Sprite.__init__(self) # Make a sprite
		self.image, self.rect = loadImage(image, colorKey) # Load the image
		self.rect.centerx = x # Place it
		self.rect.centery = y
		self.maxX = maxX
		self.maxY = maxY
		self.minX = minX
		self.minY = minY
		self.xMove = xMove
		self.yMove = yMove
	def update(self):
		self.rect.move_ip((self.xMove,self.yMove))

class gameObject(pygame.sprite.Sprite):
	def __init__(self, name, image, x, y, maxX, maxY, colorKey = -1, minX = 0, minY = 0):
		pygame.sprite.Sprite.__init__(self) # Make a sprite
		self.image, self.rect = loadImage(image, colorKey) # Load the image
		self.rect.centerx = x # Place it
		self.rect.centery = y
		self.maxX = maxX
		self.maxY = maxY
		self.minX = minX
		self.minY = minY
	def update(self, xMove, yMove, boundsCheck):
		self.rect.move_ip((xMove,yMove)) # Move things

		# bounds checking
		if boundsCheck:
			if self.rect.left < self.minX:
				self.rect.left = self.minX
			if self.rect.right > self.maxX:
				self.rect.right = self.maxX
			if self.rect.top <= self.minY:
				self.rect.top = self.minY
			if self.rect.bottom >= self.maxY:
				self.rect.bottom = self.maxY

startGame(1250, 700,'Zombie Attack!!!1!1one!', 'black.jpg', True)
pygame.mouse.set_cursor(*pygame.cursors.diamond)

playerNum = serv.joinGame()
print 'soldier' + str(playerNum%4+1) + '.png'
soldier = gameObject('soldier' + str(playerNum), 'soldier' + str(playerNum%4+1) + '.png',500, 300, 1000, 600)
soldierSprites = pygame.sprite.RenderPlain()
numPlayers = serv.numPlayers()
k = 1
while k <= numPlayers:
	if k != int(playerNum):
		newSoldier =  gameObject('soldier' + str(k), 'soldier' + str(k%4+1) + '.png',500, 300, 1000, 600)
		soldierSprites.add(newSoldier)
	if k == int(playerNum):
		soldierSprites.add(soldier)
	k = k + 1
k = 1
for player in soldierSprites:
	player.rect.centerx, player.rect.centery = serv.getPlayerPosition(k)
	k = k + 1
def createLazer(x,y, xMove, yMove):
	lazer = laserObject('bullet', 'bullet.jpg', x, y, 1000, 600, xMove, yMove, colorKey = 0)
	return lazer

lazerSprites = pygame.sprite.RenderPlain()

active = 1
xmovement = 0
ymovement = 0
i = 0
#Game Starter
while active:
	pygame.time.delay(70)
	soldierSprites.clear(screen, background_image)
	lazerSprites.clear(screen, background_image)

#Check for key presses
	for event in pygame.event.get():
		if event.type == QUIT:
			active = 0
		elif event.type == KEYDOWN:
			if event.key == K_ESCAPE:
				active = 0
			elif event.key == K_a:
				xmovement = -5
			elif event.key == K_d:
				xmovement = 5
			elif event.key == K_w:
				ymovement = -5
			elif event.key == K_s:
				ymovement = 5
		elif event.type == KEYUP:
			if event.key == K_a:
				xmovement = 0
			elif event.key == K_d:
				xmovement = 0	
			elif event.key == K_w:
				ymovement = 0
			elif event.key == K_s:
				ymovement = 0
		elif event.type == MOUSEBUTTONDOWN:
			if i > 5:
				mouse_point = pygame.mouse.get_pos()
    	    			angle_to_pointer = math.degrees(math.atan2(soldier.rect.x + soldier.rect.width / 2 - mouse_point[0], soldier.rect.y + soldier.rect.height - mouse_point[1]))
				GRAD = math.pi/180
				ddx = +math.sin(angle_to_pointer*GRAD)
         		   	ddy = +math.cos(angle_to_pointer*GRAD)
           			dx = ddx * 20
           			dy = ddy * 20
				newLazer = createLazer(soldier.rect.x + 40, soldier.rect.y+20,-dx,-dy)
				lazerSprites.add(newLazer)
				i = 0

	mouse_point = pygame.mouse.get_pos()
    	angle_to_pointer = math.degrees(math.atan2(soldier.rect.x + soldier.rect.width / 2 - mouse_point[0], soldier.rect.y + soldier.rect.height - mouse_point[1]))
	completeName = os.path.join('ZombieResources',"soldier" + str(playerNum%4+1) + ".png")
	soldier.image = pygame.transform.rotate(pygame.image.load(completeName), angle_to_pointer)
	soldier.image = soldier.image.convert()
	colorKey = soldier.image.get_at((0,0))
	soldier.image.set_colorkey(colorKey)
	soldierSprites.update(xmovement, ymovement, True)
	#Update soldier position
	serv.UpdatePosition(playerNum,soldier.rect.centerx, soldier.rect.centery)

	#Get other soldier positions
	numPlayers = serv.numPlayers()
	k = 1
	for player in soldierSprites:
		player.rect.centerx, player.rect.centery = serv.getPlayerPosition(k)
		k = k + 1
	if k <= numPlayers:
		newSoldier =  gameObject('soldier' + str(k), 'soldier' + str(k%4+1) + '.png',500, 300, 1000, 600)
		soldierSprites.add(newSoldier)
		k = k+1

	soldierSprites.draw(screen)
	lazerSprites.update()
	lazerSprites.draw(screen)
	for sprite in lazerSprites:
		if sprite.rect.top < 0:
 			sprite.kill()
		if sprite.rect.top > 600:
			sprite.kill()
		if sprite.rect.left < 0:
			sprite.kill()
		if sprite.rect.right > 1000:
			sprite.kill()
	pygame.display.flip()
	i = i + 1

