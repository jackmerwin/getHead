from SimpleXMLRPCServer import SimpleXMLRPCServer
from SimpleXMLRPCServer import SimpleXMLRPCRequestHandler
import random
import os
import math
from pygame.locals import *
from pygame.color import THECOLORS
import pygame
import sys

class RequestHandler(SimpleXMLRPCRequestHandler):
	rpc_paths = ('/RPC2')

server = SimpleXMLRPCServer((sys.argv[1], 2221), 
		requestHandler=RequestHandler)

numPlayers = 0

class Soldier:
	def __init__(self, xPos, yPos):
		self.xPos = xPos
		self.yPos = yPos

SoldierList = []

class gameFuncs:
	def joinGame(self):
		global numPlayers
		SoldierList.append(Soldier(500, 300))
		numPlayers = numPlayers + 1
		return numPlayers
	
	def UpdatePosition(self, playerNum, x, y):
		SoldierList[int(playerNum) - 1] = Soldier(x, y)
		return True
	
	def numPlayers(self):
		return numPlayers

	def getPlayerPosition(self, playerNum):
		temp = SoldierList[int(playerNum) - 1]
		return temp.xPos, temp.yPos

server.register_instance(gameFuncs())
server.serve_forever()
