import os
import pygame
import random
from pygame.locals import *
from pygame.color import THECOLORS
import math
import sys

def startGame(screenX, screenY, caption, background, cursorVisible):
	pygame.init()
	global screen
	global background_image
	screen = pygame.display.set_mode((screenX, screenY))
	pygame.display.set_caption(caption)
	background_image, background_rect = loadImage(background)
	screen.blit(background_image, (0,0))
	pygame.mouse.set_visible(cursorVisible)

def endGame(screen, kills):
	screen.fill(THECOLORS["black"])
	done = False
	font = pygame.font.Font(None, 36)
	while not done:
		
		text = font.render("Game Over", True, THECOLORS["white"], THECOLORS["black"])
		score = font.render("You pwned " + str(kills) + " zombies!", True, THECOLORS["white"], THECOLORS["black"])
		end = font.render("Press the ESC key to end.", True, THECOLORS["white"], THECOLORS["black"])
		
		screen.blit(text, (5, 5))
		screen.blit(score, (5, 40))
		screen.blit(end, (5, 75))
		pygame.display.update()
		
		events = pygame.event.get( )
		for e in events:
			if( e.type == QUIT ):
				done = True
				break
			elif (e.type == KEYDOWN):
				if( e.key == K_ESCAPE ):
					done = True

	pygame.quit()

def loadImage(name, colorKey = None):
	completeName = os.path.join('SingleZombiesResources',name) # Get a full name
	image = pygame.image.load(completeName) # load the image
	image = image.convert() # Convert the image for speed
	if colorKey != None: # colorkey (transparency) calculation
		if colorKey == -1:
			colorKey = image.get_at((0,0))
		image.set_colorkey(colorKey)
	return image, image.get_rect() 

class laserObject(pygame.sprite.Sprite):
	def __init__(self, name, image, x, y, maxX, maxY,xMove, yMove, colorKey = -1, minX = 0, minY = 0):
		pygame.sprite.Sprite.__init__(self) # Make a sprite
		self.image, self.rect = loadImage(image, colorKey) # Load the image
		self.rect.centerx = x # Place it
		self.rect.centery = y
		self.maxX = maxX
		self.maxY = maxY
		self.minX = minX
		self.minY = minY
		self.xMove = xMove
		self.yMove = yMove
	def update(self):
		self.rect.move_ip((self.xMove,self.yMove))#Keeps same movement values 

class gameObject(pygame.sprite.Sprite):
	def __init__(self, name, image, x, y, maxX, maxY, colorKey = -1, minX = 0, minY = 0):
		pygame.sprite.Sprite.__init__(self) # Make a sprite
		self.image, self.rect = loadImage(image, colorKey) # Load the image
		self.rect.centerx = x # Place it
		self.rect.centery = y
		self.maxX = maxX
		self.maxY = maxY
		self.minX = minX
		self.minY = minY
	def update(self, xMove, yMove, boundsCheck):
		self.rect.move_ip((xMove,yMove)) # Move things

		# bounds checking
		if boundsCheck:
			if self.rect.left < self.minX:
				self.rect.left = self.minX
			if self.rect.right > self.maxX:
				self.rect.right = self.maxX
			if self.rect.top <= self.minY:
				self.rect.top = self.minY
			if self.rect.bottom >= self.maxY:
				self.rect.bottom = self.maxY

# Set up the screen and allow cursor
startGame(1000, 600, 'Zombie Attack!!!1!1one!', 'black.jpg', True)
pygame.mouse.set_cursor(*pygame.cursors.diamond)

soldier = gameObject('soldier', 'soldier.png', 500, 300, 1000, 600)
soldierSprites = pygame.sprite.RenderPlain(soldier)

def createLazer(x,y, xMove, yMove):
	lazer = laserObject('bullet', 'bullet.jpg', x, y, 1000, 600, xMove, yMove, colorKey = 0)
	return lazer

def createZombie():
	x = random.randint(20, 900)
	Zombie = gameObject('zombie', 'zombie.png', x, 20, 1000, 600)
	return Zombie

zombieSprites = pygame.sprite.RenderPlain()
zombieSprites.add(createZombie())

lazerSprites = pygame.sprite.RenderPlain()

#Numbers needed to keep track of
numSoldiers = 1		#number of players alive
zombiespawn = 1
nextspawn = 2
score = 0
active = 1
xmovement = 0
ymovement = 0
i = 0
#Game Starter
while active:
	pygame.time.delay(45)
	zombieSprites.clear(screen, background_image)
	soldierSprites.clear(screen, background_image)
	lazerSprites.clear(screen, background_image)

#Check for key presses
	for event in pygame.event.get():
		if event.type == QUIT:
			active = 0
		elif event.type == KEYDOWN: #Movement keys
			if event.key == K_ESCAPE:
				active = 0
			elif event.key == K_a:
				xmovement = -5
			elif event.key == K_d:
				xmovement = 5
			elif event.key == K_w:
				ymovement = -5
			elif event.key == K_s:
				ymovement = 5
		elif event.type == KEYUP:
			if event.key == K_a:
				xmovement = 0
			elif event.key == K_d:
				xmovement = 0	
			elif event.key == K_w:
				ymovement = 0
			elif event.key == K_s:
				ymovement = 0
		elif event.type == MOUSEBUTTONDOWN: #Fire a laser towards mouse (fix up)
			#if i > 5:
				mouse_point = pygame.mouse.get_pos()
    	    			angle_to_pointer = math.degrees(math.atan2(soldier.rect.x + soldier.rect.width / 2 - mouse_point[0], soldier.rect.y + soldier.rect.height - mouse_point[1]))
				GRAD = math.pi/180
				ddx = +math.sin(angle_to_pointer*GRAD)
         		   	ddy = +math.cos(angle_to_pointer*GRAD)
           			dx = ddx * 20
           			dy = ddy * 20
				newLazer = createLazer(soldier.rect.x + 40, soldier.rect.y+20,-dx,-dy)
				lazerSprites.add(newLazer)
				i = 0
	#Update sprite location and movements
	soldierSprites.update(xmovement, ymovement, True)
	soldierSprites.draw(screen)
	lazerSprites.update()
	lazerSprites.draw(screen)

	#This section causes the zombies to chase the player
	zombiex = 1
	zombiey = 1
	for zombies in zombieSprites:
		if(zombies.rect.x < soldier.rect.x):
			zombiex = 3
		if(zombies.rect.x > soldier.rect.x):
			zombiex = -3
		if(zombies.rect.y < soldier.rect.y):
			zombiey = 3
		if(zombies.rect.y > soldier.rect.y):
			zombiey = -3
		zombies.update(zombiex, zombiey, False)
	zombieSprites.draw(screen)

	#Code for handling zombie deaths from lazer (can add more spawns)
	for hit in pygame.sprite.groupcollide(lazerSprites, zombieSprites, 1, 1):
		score = score + 1
		j = 0
		if len(zombieSprites)== 0:
			zombiespawn = nextspawn
			for j in range(zombiespawn):
				zombieSprites.add(createZombie()) 
			nextspawn = nextspawn + 1
		pygame.display.set_caption("Zombie Attack!!!1!1one!  Score:" + str(score))
	#Code handling player deaths
	for hit in pygame.sprite.groupcollide(zombieSprites, soldierSprites, 1,1):
		numSoldiers = numSoldiers - 1
		if numSoldiers == 0:
			active = 0

	for sprite in lazerSprites:
		if sprite.rect.top < 0:
 			sprite.kill()
		if sprite.rect.top > 600:
			sprite.kill()
		if sprite.rect.left < 0:
			sprite.kill()
		if sprite.rect.right > 1000:
			sprite.kill()
	pygame.display.flip()
	i = i + 1

endGame(screen, score)
