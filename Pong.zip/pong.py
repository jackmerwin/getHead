import os
import sys
import pygame
import random
from pygame.locals import *
from pygame.color import THECOLORS
import math
import socket
import threading
import pickle

def endGame(screen):
	screen.fill(THECOLORS["black"])
	done = False
	font = pygame.font.Font(None, 36)
	while not done:
		
		text = font.render("Game Over", True, THECOLORS["white"], THECOLORS["black"])
		end = font.render("Press the ESC key to end.", True, THECOLORS["white"], THECOLORS["black"])
		
		screen.blit(text, (5, 5))
		screen.blit(end, (5, 75))
		pygame.display.update()
		
		events = pygame.event.get( )
		for e in events:
			if( e.type == QUIT ):
				done = True
				break
			elif (e.type == KEYDOWN):
				if( e.key == K_ESCAPE ):
					done = True

	pygame.quit()
	exit()


def loadImage(name, colorKey = None):
	completeName = os.path.join('pongResources',name) # Get a full name
	image = pygame.image.load(completeName) # load the image
	image = image.convert() # Convert the image for speed
	if colorKey != None: # colorkey (transparency) calculation
		if colorKey == -1:
			colorKey = image.get_at((0,0))
		image.set_colorkey(colorKey)
	return image, image.get_rect()

class ball(pygame.sprite.Sprite):
	def __init__(self, xy, image, colorKey = -1):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = loadImage(image, colorKey)
		self.rect.centerx, self.rect.centery = xy
		self.velocityX = 0
		self.velocityY = 0
		self.maxspeed = 10
		self.servespeed = 5

	def reset(self):
		self.rect.centerx, self.rect.centery = 300,300
		self.velocityX = 0
		self.velocityY = 0

	def serve(self):
		angle = random.randint(-45,45)
		
		if abs(angle) < 5 or abs(angle-180) < 5:
			angle = random.randint(10,20)

		if random.random() > .5:
			angle += 180

		x = math.cos(math.radians(angle))
		y = math.sin(math.radians(angle))

		self.velocityX = self.servespeed * x
		self.velocityY = self.servespeed * y

	def move(self, dx, dy):
		if self.rect.bottom + dy >= 600:
			self.reset()
		elif self.rect.top + dy <= 0:
			self.reset()

		if self.rect.left + dx <= 0:
			self.reset()
		elif self.rect.right + dx >= 600:
			self.reset()

		self.rect.y += self.velocityY
		self.rect.x += self.velocityX

	def moveB(self, r):
		self.rect = r

	def update(self):
		self.move(self.velocityX, self.velocityY)

class paddle(pygame.sprite.Sprite):
	def __init__(self, xy, image, orientation, number, colorKey = -1):
		pygame.sprite.Sprite.__init__(self)
		self.image, self.rect = loadImage(image, colorKey)
		self.rect.centerx, self.rect.centery = xy
		self.movespeed = 7
		self.velocityV = 0
		self.velocityH = 0
		self.o = orientation
		self.num = number

	def up(self):
		self.velocityV -= self.movespeed

	def down(self):
		self.velocityV += self.movespeed

	def moveV(self, dy):
		if self.rect.bottom + dy > 600:
			self.rect.bottom = 600
		elif self.rect.top + dy < 0:
			self.rect.top = 0
		else:
			self.rect.y += dy

	def left(self):
		self.velocityH -= self.movespeed

	def right(self):
		self.velocityH += self.movespeed

	def moveH(self, dx):
		if self.rect.right + dx > 600:
			self.rect.right = 600
		elif self.rect.left + dx < 0:
			self.rect.left = 0
		else:
			self.rect.x += dx

	def update(self):
		if self.o == "v":
			self.moveV(self.velocityV)
		elif self.o == "h":
			self.moveH(self.velocityH)

	def move(self, r):
		self.rect = r

class gameObject(object):
	def __init__(self, playerNum, conn):
		pygame.init()
		self.screen = pygame.display.set_mode((600, 600))
		self.clock = pygame.time.Clock()

		# set the screen title
		pygame.display.set_caption("Pong!")

		# create the background
		self.background_image, background_rect = loadImage("black.jpg")
		self.screen.blit(self.background_image, (0,0))

		# only pay attention to certain keys
		pygame.event.set_allowed([QUIT, KEYDOWN, KEYUP])

		self.sprites = pygame.sprite.RenderUpdates()

		self.leftpaddle = paddle((50, 300), "pong_paddle_V.gif", "v", 0)
		self.sprites.add(self.leftpaddle)
		self.toppaddle = paddle((300, 50), "pong_paddle_H.gif", "h", 1)
		self.sprites.add(self.toppaddle)
		self.rightpaddle = paddle((550,300), "pong_paddle_V.gif", "v", 2)
		self.sprites.add(self.rightpaddle)
		self.bottompaddle = paddle((300, 550), "pong_paddle_H.gif", "h", 3)
		self.sprites.add(self.bottompaddle)
		self.ball = ball((300,300), "ball.gif")
		self.sprites.add(self.ball)

		# decides what player I am
		self.pNum = playerNum
		if self.pNum == 0:
			self.me = self.leftpaddle
		elif self.pNum == 1:
			self.me = self.toppaddle
		elif self.pNum == 2:
			self.me = self.rightpaddle
		elif self.pNum == 3:
			self.me = self.bottompaddle
		else:
			self = None

		#for a server this is a list, otherwise it just references the server
		self.conn = conn

	def handleEvents(self):
		for event in pygame.event.get():
			if event.type == QUIT:
				return False
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					return False
				# Players only control their own paddle
				# otherwise we'd have chaos!
				if self.pNum == 0:
					if event.key == K_UP:
						self.leftpaddle.up()
					if event.key == K_DOWN:
						self.leftpaddle.down()

				# Each pNum corresponds to another paddle
				if self.pNum == 1:
					if event.key == K_LEFT:
						self.toppaddle.left()
					if event.key == K_RIGHT:
						self.toppaddle.right()

				# pNums assigned by the order client entered the game
				if self.pNum == 2:
					if event.key == K_UP:
						self.rightpaddle.up()
					if event.key == K_DOWN:
						self.rightpaddle.down()

				# server owner gets the bottom paddle
				if self.pNum == 3:
					if event.key == K_LEFT:
						self.bottompaddle.left()
					if event.key == K_RIGHT:
						self.bottompaddle.right()

				# server gets to serve, oh ho ho...
					if event.key == K_SPACE:
						if self.ball.velocityX == 0 and self.ball.velocityY == 0:
							self.ball.serve()

			elif event.type == KEYUP:
				if self.pNum == 0:
					if event.key == K_DOWN:
						self.leftpaddle.up()
					if event.key == K_UP:
						self.leftpaddle.down()
				if self.pNum == 1:
					if event.key == K_RIGHT:
						self.toppaddle.left()
					if event.key == K_LEFT:
						self.toppaddle.right()
				if self.pNum == 2:
					if event.key == K_DOWN:
						self.rightpaddle.up()
					if event.key == K_UP:
						self.rightpaddle.down()
				if self.pNum == 3:
					if event.key == K_RIGHT:
						self.bottompaddle.left()
					if event.key == K_LEFT:
						self.bottompaddle.right()

		return True

	def collideBall(self):
		collidedX = pygame.sprite.spritecollide(self.ball, [self.leftpaddle, self.rightpaddle], dokill = False)
		collidedY = pygame.sprite.spritecollide(self.ball, [self.toppaddle, self.bottompaddle], dokill = False)

		if len(collidedX) > 0:
			self.ball.velocityX *= -1
		elif len(collidedY) > 0:
			self.ball.velocityY *= -1

	def run(self):
		running = True
		paddleData = []
		while running:
			self.clock.tick(60)
			running = self.handleEvents()

			if running == False:
				endGame(self.screen)
			

			# Server/Client Communication
			if (self.pNum == 3): #server case
				for c in self.conn:
					try:
						cNum = pickle.loads(c.recv(1024))		#get client's pNum
						c.send("ack")							#acknowldge client
						data = c.recv(1024)						#get client's paddle data
						paddleData.append(pickle.loads(data))	#place data at rigth spot in array
					except:
						print "connection lost"
						endGame(self.screen)

				paddleData.append(self.me.rect)				#add server's paddle data to array
				paddleData.append(self.ball.rect)			#stick the ball in there for good measure
				for c in self.conn:
					x = pickle.dumps(paddleData)
					c.send(x)								#send data to clients

			

			else: #client case
				x = pickle.dumps(self.me.rect)
				y = pickle.dumps(self.pNum)
				try:
					self.conn.send(y)							#tell server whos talkin
				
					self.conn.recv(1024)

					self.conn.send(x)							#send that data on over

					paddleData = (pickle.loads(self.conn.recv(1024))) #get paddle data array from server

				except:
					print "connection lost"
					endGame(self.screen)

			for sprite in self.sprites:
				self.collideBall()
				if((type(sprite) == paddle) & (sprite != self.me)):	#dont use retreived data to determine my own position
					sprite.move(paddleData[sprite.num])				#ignore velocity, just put the paddle where it should be
				else:
					self.ball.moveB(paddleData[4])
					sprite.update()									#move ball, my own paddle

			paddleData = []
			self.sprites.clear(self.screen, self.background_image)
			dirty = self.sprites.draw(self.screen)

			pygame.display.update(dirty)

class gameServer(threading.Thread):
	def __init__(self, ip):
		threading.Thread.__init__(self)
		self.host = ip
		self.port = 5556
		self.s = socket.socket()
		self.s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
		self.clients = []
		self.players = 0

	def run(self):
		pNum = 0

		self.s.bind((self.host, self.port))
		self.s.listen(5)
		while self.players < 3:
			conn, addr = self.s.accept()
			self.clients.append(conn)
			self.players = self.players + 1

			#send the player their number
		for c in self.clients:
			c.send(str(pNum))
			pNum = pNum + 1

		game = gameObject(3, self.clients)
		self.s.close()
		game.run()		

class gameClient(threading.Thread):
	def __init__(self, ip):
		threading.Thread.__init__(self)
		self.host = ip
		self.port = 5556
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	def run(self):
		self.s.connect((self.host, self.port))
		# get my player number
		num = int(self.s.recv(1024))
		game = gameObject(num, self.s)
		game.run()


def main():
	#ip = sys.argv[1]
	#own = socket.gethostbyname_ex(socket.gethostname())[2]
	#if(own[0] == ip):
	if int(sys.argv[1]) == 0:
		arg = 0
	else:
		arg = 1
	if(arg == 0):
		server = gameServer('')
		server.run()
	elif(arg > 0):
		client = gameClient('localhost')
		client.run()
	else:
		print "game is full!"
		exit()	


if __name__ == '__main__':
	main()

